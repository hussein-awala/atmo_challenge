from utils import load_data,get_data_day
import numpy as np
import pickle
import datetime
import calendar

#### Predict function for a given day

def predict(day,sites,chimeres_day,geops_day,meteo_day,concentrations_day,model=None):
    """
    day: day of the year (1-365)
    
    sites : Dataframe with columns "idPolair","nom_station","coord_x_l93","coord_y_l93","X_lamb2","Y_lamb2", "LON" ,"LAT", 
    "Département","Zone_EPCI","typologie","NO2_influence", "NO2_2012", "NO2_2013","NO2_2014","NO2_2015", "NO2_2016","NO2_2017",
    "O3_influence"   "O3_2012" ,"O3_2013", "O3_2014", "O3_2015","O3_2016" "PM10_2017","PM25_influence" "PM25_2012","PM25_2013","PM25_2014" 
     "O3_2017","PM10_influence" "PM10_2012","PM10_2013","PM10_2014","PM10_2015","PM10_2016"    
     "PM25_2015","PM25_2016","PM25_2017".
     
    chimeres_day Dict on Pollutants, for each pollutant a Dataframe with columns 'date', 'val', 'idPolair', 'param'. Stopped at D0+72H
    
    geops_day : Dict on sites, for each site a Dataframe with columns 'date', 'idPolair', 'geop_p_500hPa', 'geop_p_850hPa'. Stopped at D0+6H
    
    meteo_day : Dataframe with columns "date", "idPolair", "T2", "Q2", "U10", "V10" "PSFC", "PBLH", "LH", "HFX", "ALBEDO", "SNOWC", "HR2", "VV10", "DV10", "PRECIP". Stopped at D0+6H
    
    concentrations_day : Dict on Pollutants, for each pollutant, a dataframe with columns 'idPolair', 'Organisme', 'Station', 'Mesure', 'Date', 'Valeur'. Stopped at D0+6H
    
    model : model data (e.g. saved learned sklearn model). Change its default value if you want to load a file
    """

    # Prediction step: up to you !

    # result format
    results = dict({})
    for pol in ["PM10","PM25","O3","NO2"]:
        results[pol] = dict({})
        concentrations_pol = concentrations_day[pol]
        for idPolair in sites.idPolair:
            concentrations_pol_site = concentrations_pol[concentrations_pol.idPolair==idPolair]
            results[pol][idPolair] = dict({})
            for horizon in ["D0","D1","D2"]:
                if np.sum(~np.isnan(concentrations_pol_site.Valeur))!=0:
                    results[pol][idPolair][horizon] = np.ones(24)*np.nanmean(concentrations_pol_site.Valeur) #dummy example where we just copy for each hour the mean concentration of all previous available days 
                else:
                    results[pol][idPolair][horizon] = np.zeros(24)
    return results


#### Main loop (no need to be changed)

def run_predict(year=2016,max_days=10,n_days=None):
    """
    year : year to be evaluated
    model : model data (e.g. pickeled learned sklearn model) to be passed to the predict function
    """
    data = load_data(year=year)
    sites = data["sites"]
    day_results = []
    if n_days is None:
        if calendar.isleap(year):
            n_days = 366
        else:
            n_days = 365
    for day in range(n_days):
        print(day)
        chimeres_day,geops_day,meteo_day,concentrations_day = get_data_day(day,data,max_days=max_days,year=year) # you will get an extraction of the 2017 datasets, limited to the past of the day
        day_results.append(predict(day,sites,chimeres_day,geops_day,meteo_day,concentrations_day))
    
    pickle.dump(day_results, open('results.pk', 'wb'))




    